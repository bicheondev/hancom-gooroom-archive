#!/bin/sh
# Run this to generate all the initial makefiles, etc.

PKG_NAME="gooroom-applauncher-applet"

srcdir=`dirname $0`
test -z "$srcdir" && srcdir=.

(test -f $srcdir/configure.ac) || {
    echo -n "**Error**: Directory \"\'$srcdir\'\" does not look like the"
    echo " top-level package directory"
    exit 1
}

REQUIRED_AUTOMAKE_VERSION=1.9
. gnome-autogen.sh
