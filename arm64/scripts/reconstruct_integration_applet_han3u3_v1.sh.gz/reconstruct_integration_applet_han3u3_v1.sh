#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="${1:-work/integration-applet-reconstruction-v1}"
PUBLIC_REPO='https://github.com/gooroom/gooroom-integration-applet.git'
PUBLIC_COMMIT='168ff81421ea1f5bae9e715c5ccdd559e015d44c'
VERSION='0.3.1+grm3u1+han3u3'
POOL='https://update.hancomgooroom.com/hancom/pool/main/g/gooroom-integration-applet'
TARGET_URL="$POOL/gooroom-integration-applet_${VERSION}_amd64.deb"
TARGET_SHA='1771ded81658d0e4bcce730ab69d162a1e58327cdabf1918c341cfbd02f495a9'
DEBUG_URL="$POOL/gooroom-integration-applet-dbgsym_${VERSION}_amd64.deb"
DEBUG_SHA='806661ab9b9fef0bf14bb4a1f3e5b090ba5be84f15069f387c99ffd2c3f24c91'

rm -rf "$ROOT"
mkdir -p "$ROOT"/{downloads,target,debug,public,candidate,build-tree,build-output,recovered-resources,target-sections,analysis,output}
ROOT="$(cd "$ROOT" && pwd)"

sha_file() { sha256sum "$1" | awk '{print $1}'; }
fetch() {
  local url="$1" out="$2" expected="$3"
  curl --fail --show-error --location --retry 8 --retry-delay 2 --retry-all-errors "$url" -o "$out"
  test "$(sha_file "$out")" = "$expected"
}

fetch "$TARGET_URL" "$ROOT/downloads/target.deb" "$TARGET_SHA"
fetch "$DEBUG_URL" "$ROOT/downloads/debug.deb" "$DEBUG_SHA"
test "$(dpkg-deb -f "$ROOT/downloads/target.deb" Package)" = gooroom-integration-applet
test "$(dpkg-deb -f "$ROOT/downloads/target.deb" Version)" = "$VERSION"
test "$(dpkg-deb -f "$ROOT/downloads/target.deb" Architecture)" = amd64
dpkg-deb -x "$ROOT/downloads/target.deb" "$ROOT/target"
dpkg-deb -x "$ROOT/downloads/debug.deb" "$ROOT/debug"
dpkg-deb -f "$ROOT/downloads/target.deb" > "$ROOT/output/target-control-fields.txt"
gzip -dc "$ROOT/target/usr/share/doc/gooroom-integration-applet/changelog.gz" > "$ROOT/output/vendor-changelog.txt"

MAIN_ELF="$ROOT/target/usr/lib/x86_64-linux-gnu/gnome-panel/modules/libgooroom-integration-applet.so"
NIMF_ELF="$ROOT/target/usr/lib/x86_64-linux-gnu/nimf/modules/services/libnimf-gooroom.so"
for elf in "$MAIN_ELF" "$NIMF_ELF"; do test -f "$elf"; done

git clone --quiet --no-tags "$PUBLIC_REPO" "$ROOT/public"
git -C "$ROOT/public" checkout --quiet --detach "$PUBLIC_COMMIT"
test "$(git -C "$ROOT/public" rev-parse HEAD)" = "$PUBLIC_COMMIT"
cp -a "$ROOT/public/." "$ROOT/candidate/"

# Match the target's Debian bullseye-era GLib resource compiler rather than the
# newer host GLib/zlib implementation. Keep one helper container alive for the
# bounded reconstruction search.
RESOURCE_CONTAINER=hancom-gooroom-gresource-$$
docker run -d --name "$RESOURCE_CONTAINER" -v "$ROOT:/work" debian:bullseye sleep infinity >/dev/null
cleanup_resource_container() { docker rm -f "$RESOURCE_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup_resource_container EXIT
docker exec "$RESOURCE_CONTAINER" bash -lc 'set -Eeuo pipefail; apt-get update; apt-get install -y --no-install-recommends libglib2.0-bin' \
  > "$ROOT/output/bullseye-gresource-tooling.log" 2>&1

# Extract every architecture-neutral GResource payload directly from the target ELF.
while IFS= read -r section; do
  name="${section#.}"
  objcopy --dump-section "$section=$ROOT/target-sections/$name.gresource" "$MAIN_ELF"
done < <(readelf -S --wide "$MAIN_ELF" | awk '$2 ~ /^\.gresource\./ {print $2}')
while IFS= read -r resource; do
  out="$ROOT/recovered-resources/${resource#/}"
  mkdir -p "$(dirname "$out")"
  gresource extract "$MAIN_ELF" "$resource" > "$out"
done < <(gresource list "$MAIN_ELF")

copy_resource() {
  local resource="$1" destination="$2"
  local source="$ROOT/recovered-resources/${resource#/}"
  test -f "$source"
  mkdir -p "$(dirname "$ROOT/candidate/$destination")"
  cp "$source" "$ROOT/candidate/$destination"
}
copy_resource '/kr/gooroom/IntegrationApplet/ui/popup-window.ui' 'src/popup-window.ui'
copy_resource '/kr/gooroom/IntegrationApplet/ui/style.css' 'data/style.css'
copy_resource '/kr/gooroom/IntegrationApplet/ui/style1.css' 'data/style1.css'
copy_resource '/kr/gooroom/IntegrationApplet/ui/style2.css' 'data/style2.css'
copy_resource '/kr/gooroom/IntegrationApplet/modules/datetime/datetime-control-menu.ui' 'modules/datetime/datetime-control-menu.ui'
copy_resource '/kr/gooroom/IntegrationApplet/modules/endsession/endsession-control.ui' 'modules/endsession/endsession-control.ui'
copy_resource '/kr/gooroom/IntegrationApplet/modules/nimf/nimf-control.ui' 'modules/nimf/nimf-control.ui'
copy_resource '/kr/gooroom/IntegrationApplet/modules/security/security-control-menu.ui' 'modules/security/security-control-menu.ui'
copy_resource '/kr/gooroom/IntegrationApplet/modules/security/security-control.ui' 'modules/security/security-control.ui'
copy_resource '/kr/gooroom/IntegrationApplet/modules/updater/updater-control-menu.ui' 'modules/updater/updater-control-menu.ui'
copy_resource '/kr/gooroom/IntegrationApplet/modules/updater/updater-control.ui' 'modules/updater/updater-control.ui'
copy_resource '/kr/gooroom/IntegrationApplet/modules/user/user-control.ui' 'modules/user/user-control.ui'

# Recover the main resource XML by compiling a bounded set of equivalent descriptions
# and accepting only an exact match to the target .gresource.applet section.
python3 - "$ROOT" "$RESOURCE_CONTAINER" <<'PY'
from pathlib import Path
import hashlib, itertools, json, subprocess, sys
root=Path(sys.argv[1]); container=sys.argv[2]; candidate=root/'candidate'; target=root/'target-sections/gresource.applet.gresource'
target_sha=hashlib.sha256(target.read_bytes()).hexdigest(); attempts=[]; found=None
popup=('popup-window.ui','popup-window.ui')
styles=(('style.css','../data/style.css'),('style1.css','../data/style1.css'),('style2.css','../data/style2.css'))
for file_order in itertools.permutations((popup,)+styles):
  for compressed in itertools.product((False,True), repeat=3):
    compression=dict(zip((x[0] for x in styles),compressed))
    for strip in (False,True):
      for grouping in ('single','popup-first','popup-last','separate'):
        def file_line(item):
          name,path=item
          attrs=[]
          if name=='popup-window.ui' and strip: attrs.append('preprocess="xml-stripblanks"')
          if name!='popup-window.ui' and compression[name]: attrs.append('compressed="true"')
          if name!=path: attrs.append(f'alias="{name}"')
          suffix=(' '+ ' '.join(attrs)) if attrs else ''
          return f'    <file{suffix}>{path}</file>'
        if grouping=='single': groups=[file_order]
        elif grouping=='popup-first': groups=[(popup,),tuple(x for x in file_order if x!=popup)]
        elif grouping=='popup-last': groups=[tuple(x for x in file_order if x!=popup),(popup,)]
        else: groups=[(x,) for x in file_order]
        lines=['<?xml version="1.0" encoding="UTF-8"?>','<gresources>']
        for group in groups:
          if not group: continue
          lines.append('  <gresource prefix="/kr/gooroom/IntegrationApplet/ui">')
          lines.extend(file_line(x) for x in group)
          lines.append('  </gresource>')
        lines.extend(['</gresources>',''])
        xml='\n'.join(lines)
        probe=root/'analysis/probe-gresource.xml'; probe.write_text(xml,encoding='utf-8')
        output=root/'analysis/probe.gresource'
        p=subprocess.run(['docker','exec',container,'glib-compile-resources','/work/analysis/probe-gresource.xml','--target','/work/analysis/probe.gresource','--sourcedir','/work/candidate/src'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        row={'file_order':[x[0] for x in file_order],'compressed':compression,'stripblanks':strip,'grouping':grouping,'exit':p.returncode}
        if p.returncode==0:
          row['sha256']=hashlib.sha256(output.read_bytes()).hexdigest(); row['size']=output.stat().st_size
          if row['sha256']==target_sha:
            found={**row,'xml':xml}; (candidate/'src/gresource.xml').write_text(xml,encoding='utf-8'); attempts.append(row); break
        else: row['stderr']=p.stderr[-500:]
        attempts.append(row)
      if found: break
    if found: break
  if found: break
(root/'output/main-gresource-reconstruction.json').write_text(json.dumps({'target_sha256':target_sha,'target_size':target.stat().st_size,'matched':bool(found),'match':found,'attempt_count':len(attempts)},indent=2,sort_keys=True)+'\n')
if not found: raise SystemExit('no exact main gresource XML reconstruction matched target section')
PY
# Check whether public module resource descriptions reproduce each target section
# after replacing the UI source payloads.
python3 - "$ROOT" "$RESOURCE_CONTAINER" <<'PY'
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(sys.argv[1]); container=sys.argv[2]; candidate=root/'candidate'; rows=[]
for module,section in [('datetime','datetime_control'),('endsession','endsession_control'),('nimf','nimf_control'),('security','security_control'),('updater','updater_control'),('user','user_control')]:
  directory=candidate/'modules'/module
  xmls=sorted(directory.glob('*resource*.xml'))
  row={'module':module,'section':section,'xml_candidates':[x.name for x in xmls]}
  target=root/f'target-sections/gresource.{section}.gresource'
  row['target_sha256']=hashlib.sha256(target.read_bytes()).hexdigest(); row['target_size']=target.stat().st_size
  matches=[]
  for xml in xmls:
    out=root/f'analysis/{module}.gresource'
    p=subprocess.run(['docker','exec',container,'glib-compile-resources',f'/work/candidate/modules/{module}/{xml.name}','--target',f'/work/analysis/{module}.gresource','--sourcedir',f'/work/candidate/modules/{module}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if p.returncode==0:
      digest=hashlib.sha256(out.read_bytes()).hexdigest()
      if digest==row['target_sha256']: matches.append(xml.name)
  row['matching_xmls']=matches; row['matched']=len(matches)==1; rows.append(row)
(root/'output/module-gresource-reconstruction.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
if not all(r['matched'] for r in rows): raise SystemExit('one or more module resource sections did not reproduce exactly')
PY

# Recover exact installed icon payloads and an explicit source install manifest.
rm -f "$ROOT/candidate/icons/"*.svg
cp "$ROOT/target/usr/share/icons/hicolor/scalable/status/"*.svg "$ROOT/candidate/icons/"
cp "$ROOT/target/usr/share/icons/hicolor/scalable/actions/"*.svg "$ROOT/candidate/icons/"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1]); target=root/'target/usr/share/icons/hicolor/scalable'; dest=root/'candidate/icons/Makefile.am'
status=sorted(p.name for p in (target/'status').glob('*.svg')); actions=sorted(p.name for p in (target/'actions').glob('*.svg'))
def block(var,items):
  lines=[f'{var} = \\']
  for i,name in enumerate(items): lines.append(f'\t{name}' + (' \\' if i+1<len(items) else ''))
  return '\n'.join(lines)
text='\n'.join(['iconsymbolicstatusdir = $(datadir)/icons/hicolor/scalable/status',block('iconsymbolicstatus_DATA',status),'','iconsymbolicactionsdir = $(datadir)/icons/hicolor/scalable/actions',block('iconsymbolicactions_DATA',actions),'','gtk_update_icon_cache = gtk-update-icon-cache -f -t $(datadir)/icons/hicolor','','install-data-hook:','\t@-if test -z "$(DESTDIR)"; then \\','\t\t$(gtk_update_icon_cache); \\','\tfi','','EXTRA_DIST = $(iconsymbolicstatus_DATA) $(iconsymbolicactions_DATA)',''])
dest.write_text(text,encoding='utf-8')
PY

# Recover PO source where round-trippable, while retaining exact target MOs as a
# deterministic packaging override.
mkdir -p "$ROOT/candidate/debian/vendor-locale/en_GB" "$ROOT/candidate/debian/vendor-locale/ko"
: > "$ROOT/output/locale-roundtrip.tsv"
printf 'locale\ttarget_sha256\troundtrip_sha256\texact\n' >> "$ROOT/output/locale-roundtrip.tsv"
for locale in en_GB ko; do
  target_mo="$ROOT/target/usr/share/locale/$locale/LC_MESSAGES/gooroom-integration-applet.mo"
  recovered_po="$ROOT/candidate/po/$locale.po"
  roundtrip="$ROOT/analysis/$locale.mo"
  msgunfmt "$target_mo" -o "$recovered_po"
  msgfmt "$recovered_po" -o "$roundtrip"
  target_hash="$(sha_file "$target_mo")"; roundtrip_hash="$(sha_file "$roundtrip")"
  exact=false; [[ "$target_hash" == "$roundtrip_hash" ]] && exact=true
  printf '%s\t%s\t%s\t%s\n' "$locale" "$target_hash" "$roundtrip_hash" "$exact" >> "$ROOT/output/locale-roundtrip.tsv"
  cp "$target_mo" "$ROOT/candidate/debian/vendor-locale/$locale/gooroom-integration-applet.mo"
done

# Recover direct architecture-neutral payloads.
gschema_target="$ROOT/target/usr/share/glib-2.0/schemas/apps.gooroom-security-status.gschema.xml"
gschema_source="$(find "$ROOT/candidate" -type f -name apps.gooroom-security-status.gschema.xml -print -quit)"
test -n "$gschema_source"; cp "$gschema_target" "$gschema_source"
gzip -dc "$ROOT/target/usr/share/doc/gooroom-integration-applet/changelog.gz" > "$ROOT/candidate/debian/changelog"
cp "$ROOT/target/usr/share/doc/gooroom-integration-applet/copyright" "$ROOT/candidate/debian/copyright"

# Install exact MO payloads after the normal build to preserve byte identity.
cat >> "$ROOT/candidate/debian/rules" <<'RULES'

override_dh_auto_install:
	dh_auto_install
	find debian/gooroom-integration-applet -name '*.la' -delete
	install -D -m 0644 debian/vendor-locale/en_GB/gooroom-integration-applet.mo debian/gooroom-integration-applet/usr/share/locale/en_GB/LC_MESSAGES/gooroom-integration-applet.mo
	install -D -m 0644 debian/vendor-locale/ko/gooroom-integration-applet.mo debian/gooroom-integration-applet/usr/share/locale/ko/LC_MESSAGES/gooroom-integration-applet.mo
RULES
# Remove the original duplicate override block before retaining the appended one.
python3 - "$ROOT/candidate/debian/rules" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); t=p.read_text()
blocks=list(re.finditer(r'(?ms)^override_dh_auto_install:\n(?:\t.*\n)+',t))
if len(blocks)>1:
  first=blocks[0]; t=t[:first.start()]+t[first.end():]
p.write_text(t)
PY
chmod +x "$ROOT/candidate/debian/rules" "$ROOT/candidate/autogen.sh"

# Record the exact overlay before build products alter the tree.
git -C "$ROOT/candidate" add -A
git -C "$ROOT/candidate" diff --cached --binary > "$ROOT/output/public-168ff-to-han3u3-candidate.patch"
git -C "$ROOT/candidate" diff --cached --name-status > "$ROOT/output/overlay-name-status.tsv"
git -C "$ROOT/candidate" status --short > "$ROOT/output/candidate-status.txt"
tar --exclude=.git -C "$ROOT/candidate" -cf "$ROOT/output/gooroom-integration-applet_${VERSION}.candidate-source.tar" .
xz -9e -f "$ROOT/output/gooroom-integration-applet_${VERSION}.candidate-source.tar"
cp -a "$ROOT/candidate/." "$ROOT/build-tree/"

# Rebuild under Debian bullseye, matching the target's GCC 10.2.1 generation.
set +e
docker run --rm -v "$ROOT:/work" -w /work/build-tree debian:bullseye bash -lc '
  set -Eeuo pipefail
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y --no-install-recommends \
    automake build-essential ca-certificates debhelper devscripts dpkg-dev fakeroot \
    gnome-common gnome-pkg-tools intltool libaccountsservice-dev libcanberra-gtk3-dev \
    libglib2.0-dev libgnome-desktop-3-dev libgnome-panel-dev libgtk-3-dev libjson-c-dev \
    libnotify-dev libpolkit-gobject-1-dev libpulse-dev libstartup-notification0-dev \
    libudev-dev libupower-glib-dev libx11-dev nimf-dev pkg-config
  gcc --version | head -1
  dpkg-buildpackage -us -uc -b
  cp -v /work/gooroom-integration-applet_*_amd64.deb /work/build-output/
  cp -v /work/gooroom-integration-applet-dbgsym_*_amd64.deb /work/build-output/ 2>/dev/null || true
' > "$ROOT/output/build.log" 2>&1
BUILD_EXIT=$?
set -e
printf '%s\n' "$BUILD_EXIT" > "$ROOT/output/build.exit"

python3 - "$ROOT" "$VERSION" "$BUILD_EXIT" <<'PY'
from pathlib import Path
import hashlib,json,os,re,shutil,stat,subprocess,sys
root=Path(sys.argv[1]); version=sys.argv[2]; build_exit=int(sys.argv[3])
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def elf(p):
 try:return p.open('rb').read(4)==b'\x7fELF'
 except:return False
def run(a,**kw): return subprocess.run(a,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,**kw)
def buildid(p):
 q=run(['readelf','-n',str(p)]); m=re.search(r'Build ID:\s*([0-9a-fA-F]+)',q.stdout); return m.group(1).lower() if m else None
def section_inventory(p):
 q=run(['readelf','-SW',str(p)]); rows={}
 for line in q.stdout.splitlines():
  m=re.match(r'^\s*\[\s*\d+\]\s+(.*)$',line)
  if not m: continue
  fields=m.group(1).split()
  if not fields or not fields[0].startswith('.') or len(fields) not in (9,10): continue
  if len(fields)==10:
   name,typ,address,offset,size,entsize,flags,link,info,align=fields
  else:
   name,typ,address,offset,size,entsize,link,info,align=fields; flags=''
  row={'type':typ,'size':int(size,16),'entsize':int(entsize,16),'flags':flags,'align':int(align)}
  if typ!='NOBITS' and row['size']:
   out=root/'analysis/sections'/hashlib.sha1((str(p)+name).encode()).hexdigest()
   out.parent.mkdir(parents=True,exist_ok=True)
   r=run(['objcopy','--dump-section',f'{name}={out}',str(p)])
   if r.returncode!=0 or not out.exists(): raise RuntimeError(f'failed to dump {p}: {name}: {r.stderr}')
   row['sha256']=sha(out)
  rows[name]=row
 return rows
def normalized_allocated(rows):
 # The GNU build-id note and the non-allocated debuglink are packaging metadata.
 # Every other allocated section, including dynamic tables, relocations, unwind
 # data, writable data, BSS shape, and embedded resources, must match exactly.
 return {name:row for name,row in rows.items() if 'A' in row['flags'] and name!='.note.gnu.build-id'}
def filesystem_inventory(base):
 result={}
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base).as_posix(); st=p.lstat(); mode=stat.S_IMODE(st.st_mode)
  if p.is_symlink(): result[rel]={'kind':'symlink','mode':mode,'target':os.readlink(p)}
  elif p.is_dir(): result[rel]={'kind':'directory','mode':mode}
  elif p.is_file(): result[rel]={'kind':'file','mode':mode,'size':st.st_size,'sha256':sha(p),'elf':elf(p)}
 return result
def control_text(deb): return run(['dpkg-deb','-f',str(deb)]).stdout
summary={'schema':2,'version':version,'public_commit':'168ff81421ea1f5bae9e715c5ccdd559e015d44c','build_exit':build_exit,'build_succeeded':False,'exact_vendor_source_recovered':False,'candidate_source_reconstructed':True,'amd64_normalized_equivalence_verified':False,'native_arm64_candidate_build_allowed':False,'native_arm64_build_allowed':False,'package_promotion_allowed':False,'iso_assembly_allowed':False,'fail_closed':True}
comparison=[]; elf_rows=[]
if build_exit==0:
 debs=sorted(root.glob(f'build-output/gooroom-integration-applet_{version}_amd64.deb'))
 if len(debs)==1:
  built_deb=debs[0]; built=root/'built-root'; shutil.rmtree(built,ignore_errors=True); built.mkdir(); subprocess.run(['dpkg-deb','-x',str(built_deb),str(built)],check=True)
  target=root/'target'; target_entries=filesystem_inventory(target); built_entries=filesystem_inventory(built)
  target_paths={p.relative_to(target).as_posix():p for p in target.rglob('*')}; built_paths={p.relative_to(built).as_posix():p for p in built.rglob('*')}
  for path in sorted(set(target_entries)|set(built_entries)):
   tm=target_entries.get(path); bm=built_entries.get(path); row={'path':path,'target':tm,'built':bm,'entry_equal':False}
   if tm and bm and tm['kind']==bm['kind'] and tm['mode']==bm['mode']:
    if tm['kind'] in ('directory','symlink'):
     row['entry_equal']=tm==bm
    elif tm['kind']=='file':
     tp=target_paths[path]; bp=built_paths[path]
     if tm['elf'] and bm['elf']:
      ts=section_inventory(tp); bs=section_inventory(bp); ta=normalized_allocated(ts); ba=normalized_allocated(bs)
      er={'path':path,'target_build_id':buildid(tp),'built_build_id':buildid(bp),'target_allocated_sections':ta,'built_allocated_sections':ba,'allocated_section_names_equal':set(ta)==set(ba),'allocated_sections_equal':ta==ba,'text_equal':ts.get('.text')==bs.get('.text'),'rodata_equal':ts.get('.rodata')==bs.get('.rodata'),'resources_equal':{n:v for n,v in ts.items() if n.startswith('.gresource.')}=={n:v for n,v in bs.items() if n.startswith('.gresource.')},'raw_equal':tm['sha256']==bm['sha256']}
      elf_rows.append(er); row['entry_equal']=er['allocated_sections_equal']; row['elf_comparison']=er
     elif not tm['elf'] and not bm['elf']:
      row['entry_equal']=tm['sha256']==bm['sha256'] and tm['size']==bm['size']
     else:
      row['entry_equal']=False; row['elf_type_mismatch']=True
   comparison.append(row)
  target_elf_count=sum(1 for m in target_entries.values() if m.get('kind')=='file' and m.get('elf'))
  tree_equiv=bool(comparison) and all(r['entry_equal'] for r in comparison)
  control_target=control_text(root/'downloads/target.deb'); control_built=control_text(built_deb)
  (root/'output/target-control.normalized.txt').write_text(control_target)
  (root/'output/built-control.normalized.txt').write_text(control_built)
  control_equal=control_target==control_built
  normalized_equiv=tree_equiv and control_equal and len(elf_rows)==target_elf_count and target_elf_count>0
  summary.update({'build_succeeded':True,'built_deb':built_deb.name,'built_deb_sha256':sha(built_deb),'target_entry_count':len(target_entries),'built_entry_count':len(built_entries),'entry_mismatch_count':sum(not r['entry_equal'] for r in comparison),'target_elf_count':target_elf_count,'compared_elf_count':len(elf_rows),'control_fields_equal':control_equal,'filesystem_and_payload_equal':tree_equiv,'elf_allocated_sections_equal':bool(elf_rows) and all(r['allocated_sections_equal'] for r in elf_rows),'amd64_normalized_equivalence_verified':normalized_equiv,'native_arm64_candidate_build_allowed':normalized_equiv,'next_action':'build and verify an explicitly provisional native ARM64 candidate; promotion remains disabled' if normalized_equiv else 'inspect candidate control, filesystem, payload, and allocated ELF-section differences'})
 else:
  summary.update({'build_error':'built package selection failed','built_package_candidate_count':len(debs),'next_action':'inspect build-output package naming and build log'})
else:
 summary.update({'build_error':'Debian bullseye build failed','next_action':'repair candidate build inputs or dependency environment'})
(root/'output/payload-comparison.json').write_text(json.dumps(comparison,indent=2,sort_keys=True)+'\n')
(root/'output/elf-section-comparison.json').write_text(json.dumps(elf_rows,indent=2,sort_keys=True)+'\n')
(root/'output/summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
PY
find "$ROOT/output" -type f -printf '%P\t%s\n' | LC_ALL=C sort > "$ROOT/output/FILE-INVENTORY.tsv"
(
 cd "$ROOT/output"
 find . -type f ! -name LOCKSUMS.sha256 -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > LOCKSUMS.sha256
 sha256sum --check --strict LOCKSUMS.sha256
)
cat "$ROOT/output/summary.json"
