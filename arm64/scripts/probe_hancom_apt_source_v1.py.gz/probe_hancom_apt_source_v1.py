#!/usr/bin/env python3
"""Fail-closed probe for the exact Hancom Gooroom vendor source package in APT indices."""
from __future__ import annotations

import argparse
import bz2
import gzip
import hashlib
import html.parser
import json
import lzma
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Iterable

DEFAULT_BASES = ["https://update.hancomgooroom.com/hancom"]
DEFAULT_SUITES = [
    "hancom-2.0", "hancom-2.2", "hancom-3.0", "hancom-3.1", "hancom-3.2", "hancom-3.3",
    "gooroom-2.0", "gooroom-3.0", "gooroom-3.1", "gooroom-3.2", "gooroom-3.3",
    "buster", "bullseye", "stable", "unstable",
]
DEFAULT_COMPONENTS = ["main", "contrib", "non-free"]
DEFAULT_COMPRESSIONS = [".xz", ".gz", ".bz2", ".zst", ".lz4", ""]
USER_AGENT = "Hancom-Gooroom-ARM64-APT-Source-Probe/1"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def fetch(url: str, destination: Path, tries: int = 3, timeout: int = 90) -> dict[str, Any]:
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_name(destination.name + ".part")
    last_error: str | None = None
    http_status: int | None = None
    for attempt in range(1, tries + 1):
        try:
            request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "*/*"})
            with urllib.request.urlopen(request, timeout=timeout) as response, partial.open("wb") as out:
                http_status = getattr(response, "status", None)
                shutil.copyfileobj(response, out, 1 << 20)
            partial.replace(destination)
            return {
                "status": "downloaded",
                "url": url,
                "path": destination.as_posix(),
                "size": destination.stat().st_size,
                "sha256": sha256_file(destination),
                "http_status": http_status,
                "attempt": attempt,
            }
        except urllib.error.HTTPError as exc:
            http_status = exc.code
            last_error = f"HTTP {exc.code}: {exc.reason}"
            if exc.code in {400, 401, 403, 404, 410}:  # deterministic misses
                break
        except Exception as exc:  # network/TLS/transient
            last_error = f"{type(exc).__name__}: {exc}"
        partial.unlink(missing_ok=True)
        if attempt < tries:
            time.sleep(min(attempt * 2, 6))
    partial.unlink(missing_ok=True)
    return {"status": "unavailable", "url": url, "http_status": http_status, "error": last_error}


class LinkParser(html.parser.HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "a":
            return
        href = dict(attrs).get("href")
        if href:
            self.links.append(urllib.parse.unquote(href))


def safe_basename(value: str) -> str | None:
    parsed = urllib.parse.urlsplit(value)
    path = parsed.path if parsed.scheme else value
    name = urllib.parse.unquote(path.rstrip("/").rsplit("/", 1)[-1]).strip()
    if not name or name in {".", ".."} or "/" in name or "\\" in name or name.startswith("."):
        return None
    return name


def parse_directory_suites(index: Path) -> list[str]:
    parser = LinkParser()
    parser.feed(index.read_text(encoding="utf-8", errors="replace"))
    suites: set[str] = set()
    for link in parser.links:
        name = safe_basename(link)
        if name and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]*", name):
            suites.add(name)
    return sorted(suites)


def clear_signed_payload(data: bytes) -> bytes:
    text = data.decode("utf-8", errors="replace")
    marker = "-----BEGIN PGP SIGNED MESSAGE-----"
    if not text.startswith(marker):
        return data
    split = text.find("\n\n")
    signature = text.find("\n-----BEGIN PGP SIGNATURE-----")
    if split < 0 or signature < 0:
        return data
    body = text[split + 2 : signature]
    body = re.sub(r"(?m)^- ", "", body)
    return body.encode("utf-8")


def decompress_bytes(path: Path) -> bytes:
    data = path.read_bytes()
    suffix = path.suffix.lower()
    if suffix == ".xz":
        return lzma.decompress(data)
    if suffix == ".gz":
        return gzip.decompress(data)
    if suffix == ".bz2":
        return bz2.decompress(data)
    if suffix == ".zst":
        proc = subprocess.run(["zstd", "-q", "-d", "-c", str(path)], check=True, stdout=subprocess.PIPE)
        return proc.stdout
    if suffix == ".lz4":
        proc = subprocess.run(["lz4", "-q", "-d", "-c", str(path)], check=True, stdout=subprocess.PIPE)
        return proc.stdout
    return clear_signed_payload(data)


def parse_deb822(text: str) -> list[dict[str, str]]:
    paragraphs: list[dict[str, str]] = []
    current: dict[str, str] = {}
    current_key: str | None = None
    for raw in text.splitlines() + [""]:
        if not raw.strip():
            if current:
                paragraphs.append(current)
            current, current_key = {}, None
            continue
        if raw[0].isspace() and current_key:
            current[current_key] += "\n" + raw[1:]
            continue
        if ":" not in raw:
            continue
        key, value = raw.split(":", 1)
        current_key = key.strip()
        current[current_key] = value.lstrip()
    return paragraphs


def parse_release_paths(data: bytes) -> list[str]:
    text = clear_signed_payload(data).decode("utf-8", errors="replace")
    fields = parse_deb822(text)
    if not fields:
        return []
    paths: set[str] = set()
    for key in ("SHA256", "SHA512", "SHA1", "MD5Sum"):
        for line in fields[0].get(key, "").splitlines():
            parts = line.split()
            if len(parts) == 3:
                candidate = parts[2].lstrip("./")
                if "Sources" in candidate or "Packages" in candidate:
                    paths.add(candidate)
    return sorted(paths)


def parse_checksum_rows(value: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in value.splitlines():
        parts = line.split()
        if len(parts) == 3 and re.fullmatch(r"[0-9a-fA-F]{64}", parts[0]):
            rows.append({"sha256": parts[0].lower(), "size": int(parts[1]), "name": parts[2]})
    return rows


def exact_source_records(records: Iterable[dict[str, str]], package: str, version: str) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    package_records = [row for row in records if row.get("Package") == package]
    exact = [row for row in package_records if row.get("Version") == version]
    return package_records, exact


def verify_and_download_source(base: str, record: dict[str, str], destination: Path) -> list[dict[str, Any]]:
    directory = record.get("Directory", "").strip().strip("/")
    if not directory or ".." in directory.split("/"):
        raise RuntimeError(f"invalid source Directory: {directory!r}")
    checksums = parse_checksum_rows(record.get("Checksums-Sha256", ""))
    if not checksums:
        raise RuntimeError("exact source record has no Checksums-Sha256 rows")
    destination.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, Any]] = []
    for row in checksums:
        name = safe_basename(row["name"])
        if name != row["name"]:
            raise RuntimeError(f"unsafe source member name: {row['name']!r}")
        url = f"{base.rstrip('/')}/{directory}/{urllib.parse.quote(name)}"
        result = fetch(url, destination / name, tries=8, timeout=180)
        if result["status"] != "downloaded":
            raise RuntimeError(f"source member unavailable: {url}: {result.get('error')}")
        path = Path(result["path"])
        if path.stat().st_size != row["size"] or sha256_file(path) != row["sha256"]:
            raise RuntimeError(f"source member checksum mismatch: {name}")
        results.append({**row, **result})
    return results


def add_standard_paths(paths: set[str], components: list[str]) -> None:
    for component in components:
        for ext in DEFAULT_COMPRESSIONS:
            paths.add(f"{component}/source/Sources{ext}")
            paths.add(f"{component}/binary-amd64/Packages{ext}")


def inventory(root: Path, output: Path) -> None:
    rows: list[str] = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink() and path != output:
            rows.append(f"{path.relative_to(root).as_posix()}\t{path.stat().st_size}")
    output.write_text("\n".join(rows) + ("\n" if rows else ""), encoding="utf-8")


def locksums(root: Path) -> None:
    output = root / "LOCKSUMS.sha256"
    rows: list[str] = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and not path.is_symlink() and path != output:
            rows.append(f"{sha256_file(path)}  {path.relative_to(root).as_posix()}")
    output.write_text("\n".join(rows) + ("\n" if rows else ""), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, default=Path("work/apt-source-probe-v1"))
    parser.add_argument("--package", default="gooroom-integration-applet")
    parser.add_argument("--version", default="0.3.1+grm3u1+han3u3")
    parser.add_argument("--base", action="append", dest="bases")
    parser.add_argument("--suite", action="append", dest="suites")
    parser.add_argument("--component", action="append", dest="components")
    args = parser.parse_args()

    root = args.workspace.resolve()
    if root == Path("/"):
        raise RuntimeError("refusing root workspace")
    if root.exists():
        shutil.rmtree(root)
    for name in ("downloads", "indices", "source", "output"):
        (root / name).mkdir(parents=True, exist_ok=True)

    bases = args.bases or DEFAULT_BASES
    suites = set(args.suites or DEFAULT_SUITES)
    components = args.components or DEFAULT_COMPONENTS
    release_probes: list[dict[str, Any]] = []
    index_probes: list[dict[str, Any]] = []
    source_matches: list[dict[str, Any]] = []
    binary_matches: list[dict[str, Any]] = []
    all_source_versions: dict[str, set[str]] = {}

    for base_index, base in enumerate(bases):
        dists_index = root / "downloads" / f"base-{base_index}-dists-index.html"
        dists_result = fetch(f"{base.rstrip('/')}/dists/", dists_index, tries=2, timeout=60)
        release_probes.append({"kind": "dists-index", "base": base, **dists_result})
        if dists_result["status"] == "downloaded":
            suites.update(parse_directory_suites(dists_index))

    exact_recovered: dict[str, Any] | None = None
    for base_index, base in enumerate(bases):
        for suite in sorted(suites):
            suite_dir = root / "indices" / f"base-{base_index}" / suite
            release_paths: set[str] = set()
            for release_name in ("InRelease", "Release"):
                destination = suite_dir / release_name
                result = fetch(f"{base.rstrip('/')}/dists/{urllib.parse.quote(suite)}/{release_name}", destination, tries=2, timeout=90)
                release_probes.append({"kind": release_name, "base": base, "suite": suite, **result})
                if result["status"] == "downloaded":
                    release_paths.update(parse_release_paths(destination.read_bytes()))
            add_standard_paths(release_paths, components)

            for relative in sorted(release_paths):
                if "Sources" not in relative and "Packages" not in relative:
                    continue
                safe_relative = relative.replace("..", "_").lstrip("/")
                destination = suite_dir / safe_relative
                result = fetch(
                    f"{base.rstrip('/')}/dists/{urllib.parse.quote(suite)}/{relative}",
                    destination,
                    tries=2,
                    timeout=180,
                )
                probe_row = {"base": base, "suite": suite, "relative_path": relative, **result}
                if result["status"] != "downloaded":
                    index_probes.append(probe_row)
                    continue
                try:
                    payload = decompress_bytes(destination)
                    records = parse_deb822(payload.decode("utf-8", errors="replace"))
                    probe_row["record_count"] = len(records)
                    if "Sources" in relative:
                        package_records, exact_records = exact_source_records(records, args.package, args.version)
                        probe_row["target_package_record_count"] = len(package_records)
                        probe_row["exact_target_record_count"] = len(exact_records)
                        all_source_versions.setdefault(f"{base}|{suite}", set()).update(
                            row.get("Version", "") for row in package_records if row.get("Version")
                        )
                        for record in exact_records:
                            source_matches.append({"base": base, "suite": suite, "index_path": relative, "record": record})
                    else:
                        matches = [
                            row for row in records
                            if row.get("Package") == args.package and row.get("Version") == args.version
                        ]
                        probe_row["exact_binary_record_count"] = len(matches)
                        for record in matches:
                            binary_matches.append({"base": base, "suite": suite, "index_path": relative, "record": record})
                except Exception as exc:
                    probe_row["parse_error"] = f"{type(exc).__name__}: {exc}"
                index_probes.append(probe_row)

    # Deduplicate exact source records by base, Directory and SHA256 rows.
    unique: dict[str, dict[str, Any]] = {}
    for match in source_matches:
        record = match["record"]
        key_material = json.dumps(
            [match["base"], record.get("Directory"), record.get("Checksums-Sha256")],
            sort_keys=True,
        )
        unique[hashlib.sha256(key_material.encode()).hexdigest()] = match
    source_matches = list(unique.values())

    if len(source_matches) == 1:
        match = source_matches[0]
        downloaded = verify_and_download_source(match["base"], match["record"], root / "source")
        exact_recovered = {**match, "downloaded_files": downloaded}
        write_json(root / "output" / "exact-source-lock.json", exact_recovered)
    elif len(source_matches) > 1:
        fingerprints = {
            json.dumps(
                [row["record"].get("Directory"), row["record"].get("Checksums-Sha256")],
                sort_keys=True,
            )
            for row in source_matches
        }
        if len(fingerprints) == 1:
            match = source_matches[0]
            downloaded = verify_and_download_source(match["base"], match["record"], root / "source")
            exact_recovered = {**match, "equivalent_index_match_count": len(source_matches), "downloaded_files": downloaded}
            write_json(root / "output" / "exact-source-lock.json", exact_recovered)

    write_json(root / "output" / "release-probes.json", release_probes)
    write_json(root / "output" / "index-probes.json", index_probes)
    write_json(root / "output" / "exact-source-records.json", source_matches)
    write_json(root / "output" / "exact-binary-records.json", binary_matches)
    write_json(
        root / "output" / "available-source-versions.json",
        {key: sorted(value) for key, value in sorted(all_source_versions.items())},
    )

    recovered = exact_recovered is not None
    summary = {
        "schema": 1,
        "package": args.package,
        "version": args.version,
        "bases": bases,
        "suites": sorted(suites),
        "components": components,
        "release_probe_count": len(release_probes),
        "downloaded_release_count": sum(row["status"] == "downloaded" for row in release_probes),
        "index_probe_count": len(index_probes),
        "downloaded_index_count": sum(row["status"] == "downloaded" for row in index_probes),
        "exact_source_index_match_count": len(source_matches),
        "exact_binary_index_match_count": len(binary_matches),
        "exact_vendor_source_package_recovered": recovered,
        "amd64_rebuild_allowed": recovered,
        "native_arm64_build_allowed": False,
        "package_promotion_allowed": False,
        "iso_assembly_allowed": False,
        "fail_closed": True,
        "next_action": (
            "rebuild exact vendor source for AMD64 and verify against locked target"
            if recovered
            else "continue vendor commit and DWARF-guided source reconstruction"
        ),
    }
    write_json(root / "output" / "summary.json", summary)
    inventory(root / "output", root / "output" / "FILE-INVENTORY.tsv")
    locksums(root / "output")
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"fatal: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise
